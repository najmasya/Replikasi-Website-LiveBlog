# Blog API

Aplikasi blog sederhana berbasis **FastAPI** dengan sistem autentikasi JWT dan tampilan frontend real-time. Data disimpan secara in-memory — cocok untuk keperluan praktikum dan demo.

---

## Struktur Proyek

```
project/
├── main.py           # Backend — REST API (FastAPI)
└── frontend.html     # Frontend — Live Blog Feed
```

---

## Teknologi yang Digunakan

### Backend
| Library | Kegunaan |
|---|---|
| `fastapi` | Framework utama REST API |
| `uvicorn` | ASGI server untuk menjalankan FastAPI |
| `python-jose` | Membuat dan memverifikasi token JWT |
| `pydantic` | Validasi input request body |
| `uuid` | Menghasilkan ID unik untuk user dan blog |

### Frontend
| Teknologi | Kegunaan |
|---|---|
| HTML + CSS | Struktur dan tampilan halaman |
| Vanilla JavaScript | Logika fetch data dan render dinamis |
| Fetch API | Komunikasi dengan backend |

---

## Cara Menjalankan

### 1. Install dependencies

```bash
pip install fastapi uvicorn python-jose[cryptography]
```

### 2. Jalankan server

```bash
python main.py
```

Server akan berjalan di `http://localhost:8000`

### 3. Buka frontend

Buka file `frontend.html` langsung di browser, atau akses via server jika sudah dikonfigurasi.

### 4. Akses dokumentasi API

```
http://localhost:8000/docs
```

---

## Alur Autentikasi

```
POST /api/register  →  dapat access_token (JWT)
        ↓
Klik Authorize di /docs  →  masukkan token
        ↓
Gunakan endpoint yang memerlukan autentikasi 
```

Aplikasi ini tidak memiliki endpoint login terpisah. Setelah registrasi berhasil, token JWT langsung diberikan dan siap digunakan.

---

## Endpoint API

### Auth

| Method | Endpoint | Akses | Deskripsi |
|---|---|---|---|
| `POST` | `/api/register` | Publik | Daftar akun baru, langsung dapat token JWT |

**Request body:**
```json
{
  "nama": "Budi Santoso",
  "nim": "12345678",
  "kelas": "TI-3A"
}
```

**Response:**
```json
{
  "message": "Registrasi berhasil",
  "nama": "Budi Santoso",
  "nim": "12345678",
  "kelas": "TI-3A",
  "access_token": "eyJ...",
  "token_type": "bearer"
}
```

---

### Blog

| Method | Endpoint | Akses | Deskripsi |
|---|---|---|---|
| `GET` | `/api/blogs` | Publik | Ambil semua blog beserta data penulis |
| `POST` | `/api/blogs` | Login | Buat blog baru |
| `PUT` | `/api/blogs/{blog_id}` | Pemilik | Update blog milik sendiri |
| `DELETE` | `/api/blogs/{blog_id}` | Pemilik | Hapus blog milik sendiri |

**Request body (POST & PUT):**
```json
{
  "judul": "Judul Blog Saya",
  "isi": "Isi konten blog di sini..."
}
```

---

### Lainnya

| Method | Endpoint | Deskripsi |
|---|---|---|
| `GET` | `/` | Halaman frontend (`frontend.html`) |
| `GET` | `/health` | Status server, jumlah user, jumlah blog |
| `GET` | `/docs` | Dokumentasi Swagger UI |

---

## Sistem Otorisasi

Endpoint update dan delete memiliki dua lapis pengecekan:

```
Token valid?
  Tidak  →  401 Unauthorized
  Ya     →  lanjut
        ↓
Blog ditemukan?
  Tidak  →  404 Not Found
  Ya     →  lanjut
        ↓
Blog milik user yang login?
  Tidak  →  403 Forbidden
  Ya     →  eksekusi update / delete ✓
```

---

## Frontend — Live Blog Feed

File `frontend.html` adalah halaman single-page yang menampilkan semua blog secara real-time.

### Fitur
- Menampilkan kartu blog dengan judul, isi, nama penulis, NIM, dan kelas
- Statistik jumlah blog, jumlah penulis unik, dan waktu update terakhir
- Auto-refresh setiap **10 detik**
- Tombol refresh manual
- Tampilan waktu relatif (contoh: *5 menit lalu*)
- Indikator apakah blog pernah diedit
- Tampilan empty state jika belum ada blog
- Pesan error jika server tidak bisa dihubungi

### Konfigurasi URL

Secara default, frontend terhubung ke:

```javascript
const BASE = 'http://localhost:8000';
```

Ubah nilai ini jika server berjalan di alamat yang berbeda.

---

## Catatan Penting

- **Data bersifat sementara** — semua data (user dan blog) disimpan di RAM dan akan hilang saat server di-restart. Untuk penggunaan production, ganti dengan database seperti PostgreSQL atau SQLite.
- **SECRET_KEY** — nilai default harus diganti dengan string acak yang aman sebelum digunakan di production.
- **CORS** — saat ini dikonfigurasi untuk menerima request dari semua origin (`*`). Batasi sesuai kebutuhan di production.

---

## Kode Status HTTP

| Kode | Keterangan |
|---|---|
| `201` | Data berhasil dibuat |
| `400` | NIM sudah terdaftar |
| `401` | Token tidak ada atau tidak valid |
| `403` | Token valid, tapi bukan pemilik resource |
| `404` | Blog tidak ditemukan |
| `422` | Format request body tidak sesuai |